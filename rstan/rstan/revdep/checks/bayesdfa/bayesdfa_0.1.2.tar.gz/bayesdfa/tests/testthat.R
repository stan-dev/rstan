library(testthat)
library(bayesdfa)

test_check("bayesdfa")
