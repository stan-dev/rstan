library(testthat)
library(banocc)

test_check("banocc")
