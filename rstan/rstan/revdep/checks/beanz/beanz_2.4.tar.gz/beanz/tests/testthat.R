library(testthat)
library(beanz)

test_check("beanz")
##test_dir("./")
##test_package("beanz");
