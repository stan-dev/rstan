library("testthat")
library("blavaan")

test_check("blavaan")
