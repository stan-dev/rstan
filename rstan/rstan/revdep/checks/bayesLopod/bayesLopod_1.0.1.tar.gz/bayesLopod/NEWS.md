bayesLopod 1.0.1

Correct spelling of Psi across all package scripts
Correction in priors for stanfiles with variable detection probabilities (pi)
