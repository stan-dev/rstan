#' Coordinates for sampling events targeting a simulated species

"simSpSamplingEffort"
