#' Coordinates for detections of a simulated species

"simSpRecords"
