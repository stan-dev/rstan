#' @title breathteststan
#' @description Stan fits to 13C breath test curves. This
#'   is an add-on package to package breathtestcore (https://github.com/dmenne/breathtestcore)
#'
#' @docType package
#' @name breathteststan-package
#' @aliases breathteststan

