"summary.fitEmax"<-
function(object, ... )
{

	print(object$fit)
	return(invisible())

}

"summary.fitEmaxB"<-
function(object, ... )
{

	print(object$estanfit)
	return(invisible())

}
