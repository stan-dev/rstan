"print.fitEmax"<-
function(x, ... )
{

	print(x$fit)
	return(invisible())

}

"print.fitEmaxB"<-
function(x, ... )
{

	print(x$estanfit)
	return(invisible())

}
