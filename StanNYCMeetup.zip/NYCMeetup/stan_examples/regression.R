library(rstan)
source("regression.data.R")
ls()
posterior <- stan(file = "regression.stan", data = list(K = K, N = N, X = X, y = y, 
                  beta_0 = beta_0, A_0 = A_0, v_0 = v_0, s2_0 = s2_0),
                  iter = 1000, chains = 8)
print(posterior, pars = c("z", "beta", "sigma2"), digits = 2)
traceplot(posterior, pars = c("beta", "sigma2"))
