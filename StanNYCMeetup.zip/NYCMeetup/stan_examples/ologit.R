library(rstan)
source("ologit.data.R")
posterior <- stan(file = "ologit.stan",  chains = 8,
                  data = list(K = K, N = N, J = J, X = X, y = y, w = w, gamma = gamma) )
print(posterior, pars = c("beta", "zeta"), digits = 2)
pairs(posterior, pars = c("beta", "zeta", "lp__"))
