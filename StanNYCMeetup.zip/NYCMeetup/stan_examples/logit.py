import pystan
data = pystan.misc.read_rdump("logit.data.R")
posterior = pystan.stan(file="logit.stan", data=data,
                        iter = 1000, chains = 8)
print(posterior)


