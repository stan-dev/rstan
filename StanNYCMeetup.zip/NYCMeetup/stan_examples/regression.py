import pystan
data = pystan.misc.read_rdump("regression.data.R")
posterior = pystan.stan(file="regression.stan", data=data,
                        iter = 1000, chains = 8)
print(posterior)


