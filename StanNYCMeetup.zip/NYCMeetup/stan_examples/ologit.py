import pystan
data = pystan.misc.read_rdump("ologit.data.R")
posterior = pystan.stan(file="ologit.stan", data=data,
                        iter = 1000, chains = 8)
print(posterior)


