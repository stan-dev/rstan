import pystan
data = pystan.misc.read_rdump("poisson.data.R")
posterior = pystan.stan(file="poisson.stan", data=data,
                        iter = 1000, chains = 8)
print(posterior)


