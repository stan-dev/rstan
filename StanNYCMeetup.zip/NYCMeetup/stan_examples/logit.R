library(rstan)
source("logit.data.R")
posterior <- stan(file = "logit.stan", chains = 8,
                  data = list(K = K, N = N, X = X, y = y, gamma = gamma))
print(posterior)
pairs(posterior)
