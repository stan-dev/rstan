library(MCMCpack)
library(rstan)
data(birthwt)

X <- model.matrix(~age + as.factor(race) + smoke, data = birthwt)
N <- nrow(X)
K <- ncol(X)
y <- birthwt$low
gamma <- 10

stan_rdump(list("N", "K", "X", "y", "gamma"), file = "logit.data.R")
